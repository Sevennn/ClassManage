#include <iostream>
#include <vector>

#define MAX_STO 100

using namespace std;

struct Stu {
  string name;
  string id;
  bool sex;
  string phone;
  Stu() {
    id = "-1";
  }
  Stu(string n, string i, bool s, string p):name(n),id(i),sex(s), phone(p){}
};
class InfomationManage {
  public:
    InfomationManage();
    ~InfomationManage();
    void initStore(vector<Stu> & arr);
    void printAllInfo();
    void searchInfo(string name, string id);
    void insertInfo(Stu & node);
    void deleteInfo(string name, string id);
  private:
    Stu* sto;
    int size;
};
InfomationManage::~InfomationManage() {
  delete []sto;
}
InfomationManage::InfomationManage() {
  sto = new Stu[MAX_STO];
  size = 0;
}

void InfomationManage::initStore(vector<Stu> & arr) {
  for (int i = 0; i < arr.size(); i++) {
    if (size == MAX_STO) {
      cout << "Full !" << endl;
      return;
    }
    size++;
    int key = arr[i].name[0] % MAX_STO;
    int count = 0;
    if (sto[key].id == "-1") {
      sto[key] = arr[i];
    } else {
      while (sto[++key % MAX_STO].id != "-1") {count++;}
      sto[key % MAX_STO] = arr[i];
    }
  }
}

void InfomationManage::printAllInfo() {
  for (int i = 0; i < MAX_STO; i++) {
    if (sto[i].id != "-1") {
      cout << "name : " << sto[i].name << endl;
      cout << "id : " << sto[i].id << endl;
      cout << "Sex : " << (sto[i].sex == 1 ? "Male" : "Female") << endl;
      cout << "Phone : " << sto[i].phone << endl;
    }
  }
}

void InfomationManage::insertInfo(Stu & s) {
  if (size == MAX_STO) {
    cout << "FUll !" << endl;
    return;
  }
  int key  = s.name[0] % MAX_STO;
  int count = 0;
  if (sto[key].id == "-1") {
    sto[key] = s;
  } else {
    while (sto[++key % MAX_STO].id != "-1") {count++;}
    sto[key % MAX_STO] = s;
  }
  cout << "insert success" << endl;
}

void InfomationManage::searchInfo(string name, string id) {
  int key = name[0] % MAX_STO;
  int count = 0;
  while (sto[key].name != name || sto[key].id != id) {
    if (count == MAX_STO) {
      cout << "No such a student!" << endl;
      return;
    }
    count++;
    key = (key+1) % MAX_STO;
  }
  cout << "Compare times : " << count+1 << endl;
  cout << "name : " << sto[key].name << endl;
  cout << "id : " << sto[key].id << endl;
  cout << "Sex : " << (sto[key].sex == 1 ? "Male" : "Female") << endl;
  cout << "Phone : " << sto[key].phone << endl;
}

void InfomationManage::deleteInfo(string name, string id) {
  int key = name[0] % MAX_STO;
  int count = 0;
  while (sto[key].name != name || sto[key].id != id) {
    if (count == MAX_STO) {
      cout << "No such a student!" << endl;
      return;
    }
    count++;
    key = (key+1) % MAX_STO;
  }
  sto[key].id = "-1";
  cout << "Delete success" << endl;
}



int main() {
  cout << "Start System" << endl;
  cout << "Please input some data to init.[quit with eof]" << endl;
  cout << "format[name, id, sex(1 means male || 0 means female), phone]" << endl;
  vector<Stu> arr;
  string name, id, phone;
  InfomationManage t1;
  bool sex;
  while (cin >> name >> id >> sex >> phone) {
    Stu temp(name, id, sex, phone);
    arr.push_back(temp);
  }
  cin.clear();
  t1.initStore(arr);
  cout << "Init success!" << endl;
  cout << "Print info: " << endl;
  t1.printAllInfo();
  bool flag = true;
  while (flag) {
    cout << "-------------" << endl;
    cout << "Choose a command : " << endl;
    cout << "p : printAllInfo\ni : insertInfo\nd : deleteInfo\ns : searchInfo\nq : quit" << endl;
    cout << "-------------\n$ ";
    char command;
    cin >> command;
    switch(command) {
      case 'p' : {
        t1.printAllInfo();
        break;
      }
      case 'i' : {
        cout << "Please input info you wanna to insert : " << endl;
        cout << "format[name, id, sex(1 means male || 0 means female), phone]" << endl;
        cout << "$ ";
        string n, i, p;
        bool s;
        cin >> n >> i >> s >> p;
        Stu tmp(n, i, s, p);
        t1.insertInfo(tmp);
        break;
      }
      case 'd' : {
        cout << "Input the name and id: " << endl;
        cout << "$ ";
        string n, i;
        cin >> n >> i;
        t1.deleteInfo(n, i);
        break;
      }
      case 's': {
        cout << "Input the name and id: " << endl;
        cout << "$ ";
        string n, i;
        cin >> n >> i;
        t1.searchInfo(n, i);
        break;
      }
      case 'q' : {
        flag = false;
        cout << "bye" << endl;
        break;
      }
      default : {
        cout << "wrong choice!" << endl;
      }
    }
  }
}