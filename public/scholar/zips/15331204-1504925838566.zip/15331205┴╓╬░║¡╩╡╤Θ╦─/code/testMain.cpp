
#include "list_linear.cpp"
#include "list_order.cpp"
// pos start from 0
using namespace std;
void testOrder();
void testLinear();
int main() {
    testOrder();
    testLinear();
}

void testOrder() {
    List_order<char> list;
    cout << "Auto or not ? (1/0)" << endl;
    bool aut;
    cin >> aut;
    if (aut) {
        cout << "test List in order storage" << endl;
        string data = "COMPUTER";
            cout << "Auto test" << endl;
            cout << "Test Build a List with Arr[COMPUTER]" << endl;
            List_order<char> list1(data.c_str(), data.length());
            cout << "this List is : " << endl;
            cout << "size : " << list1.size() << endl;
            for (int i = 0; i < 8; i++) {
                cout << list1.at(i) << " ";
            }
            cout << endl;
            cout << "Test Build a List with another List[COMPUTER]" << endl;
            List_order<char> list2(list1);
            cout << "this List is : " << endl;
            cout << "size : " << list2.size() << endl;
            for (int i = 0; i < 8; i++) {
                cout << list2.at(i) << " ";
            }
            cout << endl;
            cout << "Test insert(data[COMPUTER]" << endl;
            for (int i = 0; i < 8; i++) {
                cout << (list.insert(data[i], i) == true?"insert success!":"insert failed!") << endl;
                cout << "size : " << list.size() << endl;
                cout << "insert : " << list.at(i) << endl;
            }
            cout << "Test insert while size == MAX_SIZE" << endl;
            cout << (list.insert('T', 0) == true?"insert success!":"insert failed!") << endl;
            cout << "Now erase an entry in pos 7 for the following test." << endl;
            cout << (list.erase(7) == true?"erase success!":"erase failed!") << endl;
            cout << "Test insert pos > size" << endl;
            cout << "pos is 9 while size is : " << list.size() << endl;
            cout << (list.insert('T', 9) == true?"insert success!":"insert failed!") << endl;
            cout << "Test insert pos < 0" << endl;
            cout << "pos is -1 while size is : " << list.size() << endl;
            cout << (list.insert('T', -1) == true?"insert success!":"insert failed!") << endl;
            cout << "pos 1 : " << list.at(1) << "\npos 2 : " << list.at(2) << "\npos 3 : " << list.at(3) << endl;
            cout << "Now insert 'T' in pos 2" << endl;
            cout << (list.insert('T', 2) == true?"insert success!":"insert failed!") << endl;
            cout << "now pos 2 is " << list.at(2) << endl;
            cout << "Clear the List and check the top." << endl;
            for (int i = 0; i < 8; i++) {
                cout << "top : " << list.top() << endl;
                cout << (list.erase(0) == true?"erase success!":"erase failed!") << endl;
                cout << "size : " << list.size() << endl;
            }
            cout << "Test for erase.data[COMPUTER}" << endl;
            cout << "When size == 0, try to erase" << endl;
            cout << (list.erase(0) == true?"erase success!":"erase failed!") << endl;
            for (int i = 0; i < 8; i++) {
                list.insert(data[i],i);
            }
            cout << "pos 2 is " << list.at(2) << endl;
            cout << "pos 3 is " << list.at(3) << endl;
            cout << "pos 4 is " << list.at(4) << endl;
            cout << "Now erase pos 3 \n" << (list.erase(3) == true?"erase success!":"erase failed!") << endl;
            cout << "Now pos 3 is " << list.at(3) << endl;
            cout << "Now size is " << list.size() << endl;
            cout << "Test erase pos > size - 1" << endl;
            cout << "Now erase pos " << list.size() + 1 << endl;
            cout << (list.erase(list.size()+1) == true?"erase success!":"erase failed!") << endl;
            cout << "Test erase pos < 0" << endl;
            cout << (list.erase(-1) == true?"erase success!":"erase failed!") << endl;
            cout << "Now erase all and check the top" << endl;
            for (int i = 0; i < 7; i++) {
                cout << "Top is " << list.top() << endl;
                cout << "Size is " << list.size() << endl;
                list.erase(0);
            }
        } else {
            string data = "COMPUTER";
            bool out = true;
            List_order<char> list(data.c_str(), data.length());
            cout << "Test for order List" << endl;
            cout << "I have built a list[COMPUTER] for test.(MAX_SIZE is 8)" << endl;
            while (out) {
                cout << "b : bulid a list\ni : insert\ns : size\nt : top\na : at\ne : erase\nq : quit" << endl;
                char chose;
                cin >> chose;
                switch (chose) {
                    case 'a':
                        cout << "input the pos [0, size-1]" << endl;
                        int pos;
                        cin >> pos;
                        cout << list.at(pos) << endl;
                        break;
                    case 'b' : {
                            cout << "You have three way to bulid a list." << endl;
                            cout << "in order to make it easy, I do it automatically for you." << endl;
                            cout << "Bulid a empty List" << endl;
                            List_order<char> list1;
                            cout << "its size is " << list1.size() << endl;
                            cout << "Bulid a List with arr[COMPUTER]" << endl;
                            List_order<char> list2(data.c_str(), data.length());
                            cout << "its size is " << list2.size() << endl;
                            cout << "its top is " << list2.top() << endl;
                            cout << "The whole of it is: " << endl;
                            for (int i = 0; i < 8; i++)
                                cout << list2.at(i) << " ";
                            cout << endl;
                            cout << "Bulid a List with another List[COMPUTER]" << endl;
                            List_order<char> list3(list2);
                            cout << "its size is " << list3.size() << endl;
                            cout << "its top is " << list3.top() << endl;
                            cout << "The whole of it is: " << endl;
                            for (int i = 0; i < 8; i++)
                                cout << list3.at(i) << " ";
                            cout << endl;
                            break;
                        }
                    case 'i':
                        cout << "input the pos [0, size], and data(char)" << endl;
                        int pos1;
                        char T;
                        cin >> pos1 >> T;
                        cout << (list.insert(T, pos1) == true ? "insert success" : "insert fail") << endl;
                        break;
                    case 'e':
                        cout << "input the pos [0, size-1]" << endl;
                        int pos2;
                        cin >> pos2;
                        cout << (list.erase(pos2) == true ? "erase success" : "erase fail") << endl;
                        break;
                    case 's':
                        cout << "The size is " << list.size() << endl;
                        break;
                    case 't':
                        try {
                            cout << "The top is " << list.top() << endl;
                        } catch(const char* e) {
                            cout << e << endl;
                        }
                        break;
                    case 'q':
                        out = false;
                        break;
                    default:
                        cout << "wrong input" << endl;
                }
            }
        }
}

void testLinear() {
    List_linear<char> list;
    cout << "Auto or not ? (1/0)" << endl;
    bool aut;
    cin >> aut;
    if (aut) {
        cout << "test List in order storage" << endl;
        string data = "COMPUTER";
            cout << "Auto test" << endl;
            cout << "Test Build a List with Arr[COMPUTER]" << endl;
            List_linear<char> list1(data.c_str(), data.length());
            cout << "this List is : " << endl;
            cout << "size : " << list1.size() << endl;
            for (int i = 0; i < 8; i++) {
                cout << list1.at(i) << " ";
            }
            cout << endl;
            cout << "Test Build a List with another List[COMPUTER]" << endl;
            List_linear<char> list2(list1);
            cout << "this List is : " << endl;
            cout << "size : " << list2.size() << endl;
            for (int i = 0; i < 8; i++) {
                cout << list2.at(i) << " ";
            }
            cout << endl;
            cout << "Test insert(data[COMPUTER]" << endl;
            for (int i = 0; i < 8; i++) {
                cout << (list.insert(data[i], i) == true?"insert success!":"insert failed!") << endl;
                cout << "size : " << list.size() << endl;
                cout << "insert : " << list.at(i) << endl;
            }
            cout << "Test insert while size == MAX_SIZE" << endl;
            cout << (list.insert('T', 0) == true?"insert success!":"insert failed!") << endl;
            cout << "Now erase an entry in pos 7 for the following test." << endl;
            cout << (list.erase(7) == true?"erase success!":"erase failed!") << endl;
            cout << "Test insert pos > size" << endl;
            cout << "pos is 9 while size is : " << list.size() << endl;
            cout << (list.insert('T', 9) == true?"insert success!":"insert failed!") << endl;
            cout << "Test insert pos < 0" << endl;
            cout << "pos is -1 while size is : " << list.size() << endl;
            cout << (list.insert('T', -1) == true?"insert success!":"insert failed!") << endl;
            cout << "pos 1 : " << list.at(1) << "\npos 2 : " << list.at(2) << "\npos 3 : " << list.at(3) << endl;
            cout << "Now insert 'T' in pos 2" << endl;
            cout << (list.insert('T', 2) == true?"insert success!":"insert failed!") << endl;
            cout << "now pos 2 is " << list.at(2) << endl;
            cout << "Clear the List and check the top." << endl;
            for (int i = 0; i < 8; i++) {
                cout << "top : " << list.top() << endl;
                cout << (list.erase(0) == true?"erase success!":"erase failed!") << endl;
                cout << "size : " << list.size() << endl;
            }
            cout << "Test for erase.data[COMPUTER}" << endl;
            cout << "When size == 0, try to erase" << endl;
            cout << (list.erase(0) == true?"erase success!":"erase failed!") << endl;
            for (int i = 0; i < 8; i++) {
                list.insert(data[i],i);
            }
            cout << "pos 2 is " << list.at(2) << endl;
            cout << "pos 3 is " << list.at(3) << endl;
            cout << "pos 4 is " << list.at(4) << endl;
            cout << "Now erase pos 3 \n" << (list.erase(3) == true?"erase success!":"erase failed!") << endl;
            cout << "Now pos 3 is " << list.at(3) << endl;
            cout << "Now size is " << list.size() << endl;
            cout << "Test erase pos > size - 1" << endl;
            cout << "Now erase pos " << list.size() + 1 << endl;
            cout << (list.erase(list.size()+1) == true?"erase success!":"erase failed!") << endl;
            cout << "Test erase pos < 0" << endl;
            cout << (list.erase(-1) == true?"erase success!":"erase failed!") << endl;
            cout << "Now erase all and check the top" << endl;
            for (int i = 0; i < 7; i++) {
                cout << "Top is " << list.top() << endl;
                cout << "Size is " << list.size() << endl;
                list.erase(0);
            }
        } else {
            string data = "COMPUTER";
            bool out = true;
            List_linear<char> list(data.c_str(), data.length());
            cout << "Test for linear List" << endl;
            cout << "I have built a list[COMPUTER] for test.(MAX_SIZE is 8)" << endl;
            while (out) {
                cout << "b : bulid a list\ni : insert\ns : size\nt : top\na : at\ne : erase\nq : quit" << endl;
                char chose;
                cin >> chose;
                switch (chose) {
                    case 'a':
                        cout << "input the pos [0, size-1]" << endl;
                        int pos;
                        cin >> pos;
                        cout << list.at(pos) << endl;
                        break;
                    case 'b' : {
                            cout << "You have three way to bulid a list." << endl;
                            cout << "in order to make it easy, I do it automatically for you." << endl;
                            cout << "Bulid a empty List" << endl;
                            List_linear<char> list1;
                            cout << "its size is " << list1.size() << endl;
                            cout << "Bulid a List with arr[COMPUTER]" << endl;
                            List_linear<char> list2(data.c_str(), data.length());
                            cout << "its size is " << list2.size() << endl;
                            cout << "its top is " << list2.top() << endl;
                            cout << "The whole of it is: " << endl;
                            for (int i = 0; i < 8; i++)
                                cout << list2.at(i) << " ";
                            cout << endl;
                            cout << "Bulid a List with another List[COMPUTER]" << endl;
                            List_linear<char> list3(list2);
                            cout << "its size is " << list3.size() << endl;
                            cout << "its top is " << list3.top() << endl;
                            cout << "The whole of it is: " << endl;
                            for (int i = 0; i < 8; i++)
                                cout << list3.at(i) << " ";
                            cout << endl;
                            break;
                        }
                    case 'i':
                        cout << "input the pos [0, size], and data(char)" << endl;
                        int pos1;
                        char T;
                        cin >> pos1 >> T;
                        cout << (list.insert(T, pos1) == true ? "insert success" : "insert fail") << endl;
                        break;
                    case 'e':
                        cout << "input the pos [0, size-1]" << endl;
                        int pos2;
                        cin >> pos2;
                        cout << (list.erase(pos2) == true ? "erase success" : "erase fail") << endl;
                        break;
                    case 's':
                        cout << "The size is " << list.size() << endl;
                        break;
                    case 't':
                        try {
                            cout << "The top is " << list.top() << endl;
                        } catch(const char* e) {
                            cout << e << endl;
                        }
                        break;
                    case 'q':
                        out = false;
                        break;
                    default:
                        cout << "wrong input" << endl;
                }
            }
        }
}