#include <iostream>
#include <string>
#define MAX_SIZE 8
using namespace std;

template<typename T>
class List_linear {
  public:
    struct node {
        T data;
        node* next;
        node():next(NULL){}
    };
    List_linear():size_(0){}
    List_linear(const List_linear& other) {
        int length = other.size_;
        size_ = length;
        node* p = other.head.next;
        node* last = NULL;
        while (length--) {
            node* cur = new node;
            cur->data = p->data;
            if (last)
                last->next = cur;
            if (!head.next)
                head.next = cur;
            last = cur;
            p = p->next;
        }
    }
    List_linear(const T* arr, int length) {
        int index = 0;
        size_ = length;
        node* last = NULL;
        while (length--) {
            node* p = new node;
            p->data = arr[index++];
            if (!head.next)
                head.next = p;
            if (last)
                last->next = p;
            last = p;
        }
    }
    ~List_linear() {
        node* p = head.next;
        while (p) {
            p = p->next;
            delete head.next;
            head.next = p;
        }
    }
    bool erase(int pos) {
        if (pos < 0 || pos > size_ - 1) {
            return false;
        }
        if (size_ == 1) {
            delete head.next;
            head.next = NULL;
            size_--;
            return true;
        }
        if (pos == 0) {
            node* p = head.next;
            head.next = p->next;
            delete p;
            size_--;
            return true;
        }
        int index = 0;
        node* p = head.next;
        while (index++ != pos-1) p = p->next;
        node* q = p->next->next;
        node* n = p->next;
        delete n;
        p->next = q;
        size_--;
        return true;
    }
    bool insert(T d, int pos) {
        if (pos > size_ || pos < 0)
            return false;
        if (size_+1 > MAX_SIZE)
            return false;
        if (pos == size_) {
            node* p = head.next;
            if (p)
                while (p->next) p = p->next;
            node* q = new node;
            q->data = d;
            if (head.next == NULL)
                head.next = q;
            else
                p->next = q;
            size_++;
            return true;            
        }
        int index = 0;
        node* p = head.next;
        while (index++ != pos-1) p = p->next;
        node* q = p->next;
        node* n = new node;
        n->data = d;
        p->next = n;
        n->next = q;
        size_++;
        return true;
    }
    T top() const{
        if (size_)
            return head.next->data;
        else
            throw "EMPTY LIST\n";
    }
    int size() {
        return size_;
    }
    bool empty() const {
        return size_ == 0;
    }
    T at(int pos) const {
        if (!empty()) {
            if (pos > -1 && pos < size_) {
                int index = 0;
                node* p = head.next;
                while (index++ != pos) p = p->next;
                return p->data;
            }
        }
        throw "ERROR";
    }
  private:
    node head;
    int size_;
};

