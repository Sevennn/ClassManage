#include <iostream>
#define MAX_SIZE 8
/*Pos start from 0*/
using namespace std;
template<typename T>
class List_order {
  public:
    List_order();
    List_order(const T* arr, int length) {
        for (int i = 0; i < length; i++) {
            sto[i] = arr[i];
        }
        size_ = length;
    }
    List_order(const List_order& other) {
        for (int i = 0; i < other.size_; i++) {
            sto[i] = other.sto[i];
        }
        size_ = other.size_;
    }
    bool erase(int);
    bool insert(T, int);
    T top() const;
    int size() {
        return size_;
    }
    bool empty() const {
        return size_ == 0;
    }
    T at(int pos) const {
        if (!empty()) {
            if (pos >= 0 && pos < size_) {
                return sto[pos];
            }
        }
        throw "ERROR";
    }
  private:
    T sto[MAX_SIZE+1];
    int size_;
};

template<typename T>
List_order<T>::List_order() {
    size_ = 0;
}
template<typename T>
bool List_order<T>::erase(int pos) {
    if (pos > size_-1 || pos < 0) {
        return false;
    }
    for (int i = pos; i < size_ - 1; i++)
        sto[i] = sto[i+1];
    size_--;
    return true;
}

template<typename T>
bool List_order<T>::insert(T d, int pos) {
    if (pos > size_ || pos < 0)
        return false;
    if (size_ +1 > MAX_SIZE) {
        return false;
    }
    for (int i = size_; i > pos; i--) {
        sto[i] = sto[i-1];
    }
    sto[pos] = d;
    size_++;
    return true;
}

template<typename T>
T List_order<T>::top() const{
    if (size_)
        return sto[0];
    else
        throw "EMPTY LIST\n";
}