#include <iostream>
#include <vector>
using namespace std;
void Solve(int* wei ,int W, int T, int index, int sumWei, vector<int> rec) {
    sumWei += wei[index];
    rec.push_back(wei[index]);
    if (sumWei == T) {
            cout << "(";
        for (int i = 0; i < rec.size(); i++) {
            if (i == rec.size() - 1)
                cout << rec[i] << ")" << endl;
            else
                cout << rec[i] << ", ";
        }
        return;
    }
    if (sumWei > T) {
        return;
    }
    for (int i = index + 1; i < W; i++) {
        Solve(wei, W, T, i, sumWei, rec);
    }
}
int main() {
    int W, T;
    cin >> W >> T;
    int* wei = new int[W+1];
    for (int i = 0; i < W; i++)
        wei[i] = 0;
    for (int i = 0; i < W; i++)
        cin >> wei[i];
    int sumWei = 0;
    vector<int> rec;
    for (int i = 0; i < W; i++)
        Solve(wei, W, T, i, sumWei, rec);
}
