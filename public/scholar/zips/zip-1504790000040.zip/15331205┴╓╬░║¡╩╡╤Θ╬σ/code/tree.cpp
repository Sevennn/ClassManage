#include <iostream>
#include <list>
#include <vector>
#include <queue>

using namespace std;
void outblank(int num) {
    while (num--) {
        cout << " ";
    }
}
class tree {
    public:
        struct node {
            int data;
            node* left;
            node* right;
            node():left(0), right(0){};
        };
        tree() {
            root = NULL;
            deeps = 0;
        }
        void array_bulit(vector<int>datas, list<node**>nodes, int index) {
            if (index == datas.size())
                return;
            if (root == NULL) {
                nodes.push_back(&root);
            }
            int nodeslength = 0;
            for (list<node** >::iterator it = nodes.begin(); it != nodes.end(); it++) {
                (**it) = new node;
                (**it)->data = datas[index++];
                ++nodeslength;
                if (index == datas.size())
                    break;
            }
            list<node** >::iterator it;
            while (nodeslength--) {
                it = nodes.begin();
                nodes.push_back(&((**it)->left));
                nodes.push_back(&((**it)->right));
                nodes.pop_front();
            }
            array_bulit(datas, nodes, index);
        }
        bool insert(int val, int father, int L_O_R) {
            if (root == NULL && father == -1) {
                root = new node;
                root->data = val;
                return true;
            }
            queue<node*>nodes;
            if (root)
                nodes.push(root);
            node* temp = NULL;
            while (!nodes.empty()) {
                if (nodes.front()->data == val) {
                    return false;
                }
                if (nodes.front()->left)
                    nodes.push(nodes.front()->left);
                if (nodes.front()->right)
                    nodes.push(nodes.front()->right);
                nodes.pop();

            }
            while (!nodes.empty()) nodes.pop();
            if (root)
                nodes.push(root);
            while (!nodes.empty()) {
                if (nodes.front()->data == father) {
                    temp = nodes.front();
                    break;
                }
                if (nodes.front()->left)
                    nodes.push(nodes.front()->left);
                if (nodes.front()->right)
                    nodes.push(nodes.front()->right);
                nodes.pop();
            }
            if (temp) {
                if (L_O_R == 1) {
                    if (temp->left == NULL) {
                        temp->left = new node;
                        temp->left->data = val;
                        return true;
                    }
                }
                else if (L_O_R == 0) {
                    if (temp->right == NULL) {
                        temp->right = new node;
                        temp->right->data = val;
                        return true;
                    }
                }
            }
            return false;
        }
        void revert() {
            if (root == NULL) return;
            list<node**>nodes;
            nodes.push_back(&root);
            int nodeslength = 0;
            while (true) {
                list<node**>::iterator it;
                for (it = nodes.begin(); it != nodes.end(); it++) {
                    node* temp = (**it)->left;
                    (**it)->left = (**it)->right;
                    (**it)->right = temp;
                    nodeslength++;
                }
                while (nodeslength--) {
                    it = nodes.begin();
                    if ((**it)->left != NULL)
                        nodes.push_back(&(**it)->left);
                    if ((**it)->right != NULL)
                        nodes.push_back(&(**it)->right);
                    nodes.pop_front();
                }
                if (nodes.size() == 0)
                    break;
                nodeslength = 0;
            }
        }
        void print() {
                print_tree(root, 1);
        }
        // inorder print
        void print_tree(node* t, int deep) {
            int i;
            if (t == NULL)
                return;
            print_tree(t->right, deep+1);
            for (i = 0; i < deep; i++) {
                cout << " ";
            }

            cout << t->data << endl;
            print_tree(t->left, deep+1);
        }
    private:
        node* root;
        int deeps;

};

int main() {
    vector<int>datas;
    list<tree::node**>nodes;
    tree test1;
    int data;
    cout << "Built tree with arr or insert ?" << endl;
    cout << "input 1 or 0 to choose : ";
    int chose;
    cin >> chose;
    if (chose == 1) {
        cout << "input data(num) : (end with eof)" << endl;
        vector<int>datas;
        while (cin >> data) {
            datas.push_back(data);
        }
        test1.array_bulit(datas, nodes, 0);
        cout << "now the tree is : " << endl;
        test1.print();
        cout << "------------After revert-------------" << endl;
        test1.revert();
        test1.print();
    }
    else if (chose == 0) {
        cout << "input node[Val, Father_val, Left(1) or Right(0)], such as 0 1 1" << endl;
        cout << "The root should be  val -1 0" << endl;
        cout << "Now start to insert![-1,-1,-1] to quit" << endl;
        while (true) {
            int father, val, LOR;
            cin>>val>>father>>LOR;
            if (val == -1 && father == -1 && LOR == -1)
                break;
            if (test1.insert(val, father, LOR)) {
                cout << "insert success!" << endl;
            } else {
                cout << "insert fail!" << endl;
            }
        }
        cout << "now the tree is : " << endl;
        test1.print();
        cout << "----------After revert------------" << endl;
        test1.revert();
        test1.print();
    }
}